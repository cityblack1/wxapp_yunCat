"""
Unit tests for L{twisted.python}.
"""
